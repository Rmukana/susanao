bl_info = {
    "name": "susanaò",
    "author": "Susanawo × Claude (Anthropic)",
    "version": (1, 3, 6),
    "blender": (3, 3, 0),
    "location": "View3D > Sidebar > susanaò",
    "description": "Screen-partition boundary cut; extract inside area as a separate object",
    "category": "3D View",
}

import os
import bpy
import bmesh
import gpu
import math
import bpy.utils.previews
from gpu_extras.batch import batch_for_shader
from mathutils import Vector, kdtree
from bpy_extras import view3d_utils

ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
custom_icons = None

# ============================================================
# KDTree Cache
# ============================================================
_KD_CACHE = {
    'mesh_name': None,
    'vertex_count': 0,
    'kd': None,
    'world_matrix': None,
}

def _get_or_build_kdtree(obj):
    global _KD_CACHE
    vertex_count = len(obj.data.vertices)
    mesh_name = obj.name
    world_matrix = obj.matrix_world.copy()
    cache_valid = (
        _KD_CACHE['mesh_name'] == mesh_name
        and _KD_CACHE['vertex_count'] == vertex_count
        and _KD_CACHE['kd'] is not None
        and _KD_CACHE['world_matrix'] is not None
    )
    if cache_valid:
        try:
            diff = sum(
                abs(_KD_CACHE['world_matrix'][i][j] - world_matrix[i][j])
                for i in range(4) for j in range(4)
            )
            if diff < 1e-6:
                return _KD_CACHE['kd'], False
        except Exception:
            pass
    kd = kdtree.KDTree(vertex_count)
    for i, v in enumerate(obj.data.vertices):
        kd.insert(v.co, i)
    kd.balance()
    _KD_CACHE['mesh_name'] = mesh_name
    _KD_CACHE['vertex_count'] = vertex_count
    _KD_CACHE['kd'] = kd
    _KD_CACHE['world_matrix'] = world_matrix
    return kd, True

def _clear_kdtree_cache():
    global _KD_CACHE
    _KD_CACHE = {
        'mesh_name': None,
        'vertex_count': 0,
        'kd': None,
        'world_matrix': None,
    }

# ============================================================
# X-Ray Control
# ============================================================
def _get_xray_state(context):
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    try:
                        return space.shading.show_xray
                    except AttributeError:
                        return False
    return False

def _set_xray_state(context, state):
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    try:
                        space.shading.show_xray = state
                    except AttributeError:
                        pass
                    area.tag_redraw()

def _redraw_all():
    try:
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
    except Exception:
        pass

def _remove_loading_overlay():
    handle = _LOADING.get('overlay_handle')
    area = _LOADING.get('overlay_area')
    if handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
        except Exception:
            pass
        _LOADING['overlay_handle'] = None
    _LOADING['overlay_area'] = None
    if area is not None:
        try:
            area.header_text_set(None)
            area.tag_redraw()
        except Exception:
            pass
    _redraw_all()

# ============================================================
# Loading State
# ============================================================
_LOADING = {
    'active': False,
    'frame': 0,
    'total_frames': 1,
    'context_data': None,
    'result_msg': '',
    'operation': 'separate',
    'overlay_handle': None,
    'overlay_area': None,
}

def _get_interval(frame, total_frames):
    if total_frames <= 1:
        return 0.1
    t = frame / float(total_frames)
    return 0.3 + (2.5 - 0.3) * (t ** 2)

def _start_loading(obj, p1_x, p1_y, p2_x, p2_y, region, rv3d, operation='separate', overlay_handle=None, overlay_area=None):
    _LOADING['active'] = True
    _LOADING['frame'] = 0
    _LOADING['result_msg'] = ''
    _LOADING['operation'] = operation
    _LOADING['overlay_handle'] = overlay_handle
    _LOADING['overlay_area'] = overlay_area
    _LOADING['context_data'] = {
        'obj_name': obj.name,
        'p1_x': p1_x, 'p1_y': p1_y, 'p2_x': p2_x, 'p2_y': p2_y,
        'region': region,
        'rv3d': rv3d,
    }
    _redraw_all()
    bpy.app.timers.register(_tick_loading, first_interval=_get_interval(0, _LOADING['total_frames']))

def _tick_loading():
    if not _LOADING['active']:
        _remove_loading_overlay()
        return None
    _LOADING['frame'] += 1
    _redraw_all()
    if _LOADING['frame'] > _LOADING['total_frames']:
        try:
            _run_processing()
        except Exception as e:
            _LOADING['result_msg'] = f'ERROR: {e}'
        finally:
            _LOADING['active'] = False
            _remove_loading_overlay()
        return None
    return _get_interval(_LOADING['frame'], _LOADING['total_frames'])

def _run_processing():
    data = _LOADING['context_data']
    if data is None:
        return
    obj = bpy.data.objects.get(data['obj_name'])
    if obj is None or obj.type != 'MESH':
        _LOADING['result_msg'] = 'ERROR: Mesh not found'
        return
    p1_x, p1_y, p2_x, p2_y = data['p1_x'], data['p1_y'], data['p2_x'], data['p2_y']
    region = data['region']
    rv3d = data['rv3d']
    xray_before = _get_xray_state(bpy.context)
    mesh = obj.data

    _do_partition_cut(obj, mesh, p1_x, p1_y, p2_x, p2_y, region, rv3d, xray_before)

def _screen_partition_plane(region, rv3d, p1, p2):
    co_a = Vector((float(p1[0]), float(p1[1])))
    co_b = Vector((float(p2[0]), float(p2[1])))

    origin_a = view3d_utils.region_2d_to_origin_3d(region, rv3d, co_a)
    origin_b = view3d_utils.region_2d_to_origin_3d(region, rv3d, co_b)
    direction_a = view3d_utils.region_2d_to_vector_3d(region, rv3d, co_a).normalized()

    point_a = origin_a + direction_a * 10.0
    point_b = origin_b + direction_a * 10.0
    point_c = origin_a + direction_a * 11.0
    
    normal = (point_b - point_a).cross(point_c - point_a)
    if normal.length < 1.0e-10:
        raise ValueError("Cannot create cutting plane from screen partition")
    normal.normalize()
    return point_a, normal

def _do_partition_cut(obj, mesh, p1_x, p1_y, p2_x, p2_y, region, rv3d, xray_before):
    try:
        active = bpy.context.view_layer.objects.active
        if active is not None and active.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        _set_xray_state(bpy.context, True)
        bpy.ops.mesh.select_all(action='DESELECT')

        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()

        matrix_world = obj.matrix_world.copy()
        
        world_plane = _screen_partition_plane(region, rv3d, (p1_x, p1_y), (p2_x, p2_y))
        plane_co_world = world_plane[0]
        plane_no_world = world_plane[1]

        world_to_local = obj.matrix_world.inverted()
        world_normal_to_local = obj.matrix_world.to_3x3().transposed()

        plane_co_local = world_to_local @ plane_co_world
        plane_no_local = world_normal_to_local @ plane_no_world
        if plane_no_local.length > 1.0e-12:
            plane_no_local.normalize()
            geom = list(bm.verts) + list(bm.edges) + list(bm.faces)
            bmesh.ops.bisect_plane(
                bm,
                geom=geom,
                dist=1.0e-6,
                plane_co=plane_co_local,
                plane_no=plane_no_local,
                clear_inner=False,
                clear_outer=False,
            )

        bm.normal_update()
        selected_count = 0
        
        for face in bm.faces:
            face.select_set(False)
            
        for face in bm.faces:
            center_world = matrix_world @ face.calc_center_median()
            val = (center_world - plane_co_world).dot(plane_no_world)
            if val > 0:
                face.select_set(True)
                selected_count += 1

        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=True)
        
        if selected_count == 0:
            bpy.ops.object.mode_set(mode='OBJECT')
            _set_xray_state(bpy.context, xray_before)
            _LOADING['result_msg'] = 'WARNING: No faces to cut out'
            return

        bpy.ops.mesh.separate(type='SELECTED')
        bpy.ops.object.mode_set(mode='OBJECT')
        _set_xray_state(bpy.context, xray_before)
        _LOADING['result_msg'] = f'Done: Separated {selected_count:,} faces'

    except Exception as e:
        try:
            if bpy.context.object is not None and bpy.context.object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            _set_xray_state(bpy.context, xray_before)
        except Exception:
            pass
        _LOADING['result_msg'] = f'ERROR: {e}'

# ============================================================
# Base Operator (Modal Partition)
# ============================================================
class BOX_SEP_OT_base(bpy.types.Operator):
    bl_options = {'REGISTER', 'UNDO'}
    _operation = 'separate'
    RECT_COLOR = (0.0, 0.85, 1.0, 1.0)
    RECT_WIDTH = 1.5

    _mode = 'IDLE'
    _p1_x = 0.0
    _p1_y = 0.0
    _p2_x = 0.0
    _p2_y = 0.0
    _drag_start_x = 0.0
    _drag_start_y = 0.0
    _orig_p1_x = 0.0
    _orig_p1_y = 0.0
    _orig_p2_x = 0.0
    _orig_p2_y = 0.0
    _handle = None

    def _common_invoke(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a mesh")
            return {'CANCELLED'}
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'ERROR'}, "Please run in 3D View")
            return {'CANCELLED'}
        if _LOADING['active']:
            self.report({'WARNING'}, "Processing is already in progress")
            return {'CANCELLED'}
            
        self._mode = 'IDLE'
        cx = context.region.width / 2.0
        cy = context.region.height / 2.0
        w = context.region.width * 0.3
        
        self._p1_x = cx - (w / 2.0)
        self._p1_y = cy
        self._p2_x = cx + (w / 2.0)
        self._p2_y = cy
        
        self._drag_start_x = 0.0
        self._drag_start_y = 0.0
        self._orig_p1_x = 0.0
        self._orig_p1_y = 0.0
        self._orig_p2_x = 0.0
        self._orig_p2_y = 0.0
        
        args = (self, context)
        self._draw_area = context.area
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            self._draw_partition, args, 'WINDOW', 'POST_PIXEL'
        )
        context.window_manager.modal_handler_add(self)
        try:
            context.area.header_text_set(
                "Drag line to move / Drag ends to resize / R / Shift+R to rotate / Enter to confirm / Esc to cancel"
            )
        except Exception:
            pass
            
        context.area.tag_redraw()
        
        return {'RUNNING_MODAL'}

    def _draw_partition(self, op, context):
        coords = [
            (op._p1_x, op._p1_y),
            (op._p2_x, op._p2_y),
        ]
        hs = 6
        handle_coords = [
            (op._p1_x - hs, op._p1_y - hs), (op._p1_x + hs, op._p1_y - hs), (op._p1_x + hs, op._p1_y - hs), (op._p1_x + hs, op._p1_y + hs), (op._p1_x + hs, op._p1_y + hs), (op._p1_x - hs, op._p1_y + hs), (op._p1_x - hs, op._p1_y + hs), (op._p1_x - hs, op._p1_y - hs),
            (op._p2_x - hs, op._p2_y - hs), (op._p2_x + hs, op._p2_y - hs), (op._p2_x + hs, op._p2_y - hs), (op._p2_x + hs, op._p2_y + hs), (op._p2_x + hs, op._p2_y + hs), (op._p2_x - hs, op._p2_y + hs), (op._p2_x - hs, op._p2_y + hs), (op._p2_x - hs, op._p2_y - hs),
        ]
        
        try:
            gpu.state.line_width_set(op.RECT_WIDTH)
            is_legacy = bpy.app.version < (4, 0, 0)
            if is_legacy:
                shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
                shader.bind()
                batch = batch_for_shader(shader, 'LINES', {'pos': coords})
                shader.uniform_float('color', op.RECT_COLOR)
                batch.draw(shader)
                batch_h = batch_for_shader(shader, 'LINES', {'pos': handle_coords})
                shader.uniform_float('color', (1.0, 1.0, 1.0, 1.0))
                batch_h.draw(shader)
            else:
                # Blender 4.0+ 向けの修正: シェーダー名を 'UNIFORM_COLOR' に変更
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                shader.bind()
                
                # 線の描画
                batch = batch_for_shader(shader, 'LINES', {'pos': coords})
                shader.uniform_float('color', op.RECT_COLOR)
                batch.draw(shader)
                
                # ハンドルの描画
                batch_h = batch_for_shader(shader, 'LINES', {'pos': handle_coords})
                shader.uniform_float('color', (1.0, 1.0, 1.0, 1.0))
                batch_h.draw(shader)
            
            gpu.state.line_width_set(1.0)
        except Exception as e:
            # エラーをコンソールに出力（デバッグ用）
            print(f"Draw Error: {e}")
            pass

    def modal(self, context, event):
        if event.type == 'ESC':
            self._cleanup()
            try:
                context.area.header_text_set(None)
            except Exception:
                pass
            return {'CANCELLED'}

        if event.type == 'R' and event.value == 'PRESS':
            deg = -5.0 if event.shift else 5.0
            rad = math.radians(deg)
            
            cx = (self._p1_x + self._p2_x) / 2.0
            cy = (self._p1_y + self._p2_y) / 2.0
            
            cos_a = math.cos(rad)
            sin_a = math.sin(rad)
            
            v1x = self._p1_x - cx
            v1y = self._p1_y - cy
            self._p1_x = cx + (v1x * cos_a - v1y * sin_a)
            self._p1_y = cy + (v1x * sin_a + v1y * cos_a)
            
            v2x = self._p2_x - cx
            v2y = self._p2_y - cy
            self._p2_x = cx + (v2x * cos_a - v2y * sin_a)
            self._p2_y = cy + (v2x * sin_a + v2y * cos_a)
            
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type in {'RET', 'NUMPAD_ENTER'}:
            length = math.hypot(self._p2_x - self._p1_x, self._p2_y - self._p1_y)
            if length > 3:
                obj = context.active_object
                region = context.region
                rv3d = context.space_data.region_3d
                overlay_handle = self._handle
                overlay_area = context.area
                self._handle = None
                _start_loading(
                    obj,
                    self._p1_x, self._p1_y, self._p2_x, self._p2_y,
                    region, rv3d,
                    operation=self._operation,
                    overlay_handle=overlay_handle,
                    overlay_area=overlay_area,
                )
                try:
                    context.area.header_text_set("Processing...")
                    context.area.tag_redraw()
                except Exception:
                    pass
                self.report({'INFO'}, "Processing started")
                return {'FINISHED'}
            else:
                self.report({'WARNING'}, "Partition is too short")
                return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            mx, my = event.mouse_region_x, event.mouse_region_y
            handle_size = 15
            
            dist1 = math.hypot(mx - self._p1_x, my - self._p1_y)
            dist2 = math.hypot(mx - self._p2_x, my - self._p2_y)
            
            if dist1 < handle_size:
                self._mode = 'RESIZE_P1'
            elif dist2 < handle_size:
                self._mode = 'RESIZE_P2'
            else:
                l2 = (self._p2_x - self._p1_x)**2 + (self._p2_y - self._p1_y)**2
                if l2 == 0:
                    self._mode = 'IDLE'
                else:
                    t = max(0, min(1, ((mx - self._p1_x) * (self._p2_x - self._p1_x) + (my - self._p1_y) * (self._p2_y - self._p1_y)) / l2))
                    proj_x = self._p1_x + t * (self._p2_x - self._p1_x)
                    proj_y = self._p1_y + t * (self._p2_y - self._p1_y)
                    dist_line = math.hypot(mx - proj_x, my - proj_y)
                    
                    if dist_line < 10.0:
                        self._mode = 'MOVE'
                    else:
                        self._mode = 'IDLE'
                        
            if self._mode != 'IDLE':
                self._drag_start_x = mx
                self._drag_start_y = my
                self._orig_p1_x = self._p1_x
                self._orig_p1_y = self._p1_y
                self._orig_p2_x = self._p2_x
                self._orig_p2_y = self._p2_y
                
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            if self._mode == 'IDLE':
                return {'RUNNING_MODAL'}
                
            mx, my = event.mouse_region_x, event.mouse_region_y
            
            if self._mode == 'MOVE':
                dx = mx - self._drag_start_x
                dy = my - self._drag_start_y
                self._p1_x = self._orig_p1_x + dx
                self._p1_y = self._orig_p1_y + dy
                self._p2_x = self._orig_p2_x + dx
                self._p2_y = self._orig_p2_y + dy
                
            elif self._mode == 'RESIZE_P1':
                vx = self._orig_p1_x - self._orig_p2_x
                vy = self._orig_p1_y - self._orig_p2_y
                v_len = math.hypot(vx, vy)
                if v_len > 0.001:
                    nx = vx / v_len
                    ny = vy / v_len
                    px = mx - self._orig_p2_x
                    py = my - self._orig_p2_y
                    proj = px * nx + py * ny
                    self._p1_x = self._orig_p2_x + nx * proj
                    self._p1_y = self._orig_p2_y + ny * proj
                    
            elif self._mode == 'RESIZE_P2':
                vx = self._orig_p2_x - self._orig_p1_x
                vy = self._orig_p2_y - self._orig_p1_y
                v_len = math.hypot(vx, vy)
                if v_len > 0.001:
                    nx = vx / v_len
                    ny = vy / v_len
                    px = mx - self._orig_p1_x
                    py = my - self._orig_p1_y
                    proj = px * nx + py * ny
                    self._p2_x = self._orig_p1_x + nx * proj
                    self._p2_y = self._orig_p1_y + ny * proj
                
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self._mode = 'IDLE'
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        return {'RUNNING_MODAL'}

    def _cleanup(self):
        if self._handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            except Exception:
                pass
            self._handle = None
        area = getattr(self, '_draw_area', None)
        if area is not None:
            try:
                area.tag_redraw()
            except Exception:
                pass
        _redraw_all()


class BOX_SEP_OT_start(BOX_SEP_OT_base):
    bl_idname = "box_sep.start"
    bl_label = "Separate"
    bl_description = "Drag line to cut and separate"

    def invoke(self, context, event):
        self._operation = 'separate'
        self.RECT_COLOR = (0.0, 0.85, 1.0, 1.0)
        return self._common_invoke(context)


class BOX_SEP_OT_invert(BOX_SEP_OT_base):
    bl_idname = "box_sep.invert"
    bl_label = "Invert Selection"
    bl_description = "Cut at partition boundary and separate the inside as a new object"

    def invoke(self, context, event):
        self._operation = 'invert'
        self.RECT_COLOR = (1.0, 0.4, 0.0, 1.0)
        return self._common_invoke(context)


class BOX_SEP_OT_clear_cache(bpy.types.Operator):
    bl_idname = "box_sep.clear_cache"
    bl_label = "Clear KDTree Cache"
    bl_description = "Clear KDTree cache"

    def execute(self, context):
        _clear_kdtree_cache()
        self.report({'INFO'}, "KDTree cache cleared")
        return {'FINISHED'}


# ============================================================
# Panel UI
# ============================================================
class BOX_SEP_PT_panel(bpy.types.Panel):
    bl_label = "susanaò"
    bl_idname = "BOX_SEP_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "susanaò"

    def draw(self, context):
        layout = self.layout
        
        header_row = layout.row()
        header_row.alignment = 'RIGHT'
        header_row.scale_y = 0.8
        header_row.label(text="Free vr1")

        if _LOADING['active']:
            load_box = layout.box()
            load_box.label(text="Processing...", icon='TIME')
            
            if custom_icons and "loading_img" in custom_icons:
                load_box.template_icon(icon_value=custom_icons["loading_img"].icon_id, scale=10.0)
            
            load_box.label(text="Loading...")
            return

        sep_icon = custom_icons.get("sep_ico") if custom_icons and "sep_ico" in custom_icons else None
        inv_icon = custom_icons.get("inv_ico") if custom_icons and "inv_ico" in custom_icons else None

        row = layout.row()
        sep_text = "Sep\u200barate"
        if sep_icon:
            row.operator(BOX_SEP_OT_start.bl_idname, text=sep_text, icon_value=sep_icon.icon_id)
        else:
            row.operator(BOX_SEP_OT_start.bl_idname, text=sep_text)

        layout.separator()
        
        row2 = layout.row()
        row2.enabled = False
        inv_text = "Invert Selection ★pro"
        if inv_icon:
            row2.operator(BOX_SEP_OT_invert.bl_idname, text=inv_text, icon_value=inv_icon.icon_id)
        else:
            row2.operator(BOX_SEP_OT_invert.bl_idname, text=inv_text)
            
        row_pro = layout.row()
        row_pro.alignment = 'RIGHT'
        row_pro.label(text="Prototype")

        if _LOADING['result_msg']:
            result_box = layout.box()
            result_box.label(text=_LOADING['result_msg'])

        layout.separator()
        
        cache_box = layout.box()
        cache_text = "Ca\u200bche"
        cache_box.label(text=cache_text, icon='FILE_CACHE')
        cache = _KD_CACHE
        if cache['kd'] is not None:
            cache_box.label(text=f"OK: {cache['mesh_name']}", icon='CHECKMARK')
            cache_box.label(text=f"  Verts: {cache['vertex_count']:,}")
        else:
            cache_box.label(text="(Not Built)")
        
        clear_cache_text = "Clear Ca\u200bche"
        cache_box.operator(BOX_SEP_OT_clear_cache.bl_idname, text=clear_cache_text)

        layout.separator(factor=1.0)
        bottom_row = layout.row()
        bottom_row.alignment = 'RIGHT'
        bottom_row.scale_y = 0.7
        bottom_row.label(text="Anthropic Claude")


# ============================================================
# Registration
# ============================================================
CLASSES = (
    BOX_SEP_OT_start,
    BOX_SEP_OT_invert,
    BOX_SEP_OT_clear_cache,
    BOX_SEP_PT_panel,
)

def register():
    global custom_icons
    if custom_icons is None:
        custom_icons = bpy.utils.previews.new()
        
        img_files = {
            "sep_ico": "separate_ico.png",
            "inv_ico": "Invert_Selection_ico.png",
            "loading_img": "Loading.png"
        }
        
        for key, filename in img_files.items():
            fp = os.path.join(ADDON_DIR, filename)
            if os.path.exists(fp):
                try:
                    custom_icons.load(key, fp, "IMAGE")
                except Exception:
                    pass

    for cls in CLASSES:
        bpy.utils.register_class(cls)

def unregister():
    global custom_icons
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    if custom_icons is not None:
        bpy.utils.previews.remove(custom_icons)
        custom_icons = None

if __name__ == "__main__":
    register()